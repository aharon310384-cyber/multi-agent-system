"""
AgentMemory MCP MemoryProvider plugin — полная MCP-интеграция v0.9.21.

Использует AgentMemory MCP-сервер напрямую для ВСЕХ операций.
НЕ использует REST API — только MCP через встроенный клиент Hermes.

AgentMemory подключается в config.yaml:
  mcp_servers:
    agentmemory:
      url: http://agentmemory:3111/mcp
      timeout: 120
      enabled: true

Этот плагин:
  1. Регистрирует 53 tool schemas в Hermes tool registry
  2. Обеспечивает автоматический prefetch через MCP
  3. Обеспечивает автоматический sync_turn через MCP
  4. Обеспечивает on_session_end extraction

Совместим с: Hermes Agent, Claude Code, Cursor, OpenCode, Codex, Gemini CLI.

AgentMemory v0.9.21 — 53 MCP tools, 124 REST endpoints, 12 hooks, 4 skills.
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ============================================
# Tool Schemas — полный набор AgentMemory v0.9.21 (53 tools)
# ============================================

ALL_SCHEMAS: List[Dict[str, Any]] = [
    # === CORE TOOLS (always available) ===
    {
        "name": "memory_recall",
        "description": "Search past session observations for relevant context. Use when you need to recall what happened in previous sessions, find past decisions, or locate specific information from earlier work.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query (keywords, file names, concepts)"},
                "format": {"type": "string", "enum": ["full", "compact", "narrative"], "description": "Result format (default: full)"},
                "limit": {"type": "integer", "description": "Max results to return (default: 10)"},
                "token_budget": {"type": "integer", "description": "Optional token budget to trim returned results"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_save",
        "description": "Explicitly save an important insight, decision, or pattern to long-term memory.",
        "parameters": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The insight or decision to remember"},
                "type": {"type": "string", "enum": ["pattern", "preference", "architecture", "bug", "workflow", "fact"], "description": "Memory type"},
                "concepts": {"type": "string", "description": "Comma-separated key concepts"},
                "files": {"type": "string", "description": "Comma-separated relevant file paths"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "memory_smart_search",
        "description": "Hybrid semantic+keyword search with progressive disclosure.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "limit": {"type": "integer", "description": "Max results (default: 10)"},
                "expandIds": {"type": "string", "description": "Comma-separated observation IDs to expand"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_vision_search",
        "description": "Cross-modal image search via CLIP embeddings. Pass queryText to find screenshots matching a description, or queryImageBase64/queryImageRef to find similar images.",
        "parameters": {
            "type": "object",
            "properties": {
                "queryText": {"type": "string", "description": "Text query (e.g. 'login form with error banner')"},
                "queryImageBase64": {"type": "string", "description": "Raw base64 image bytes or data URL"},
                "queryImageRef": {"type": "string", "description": "Absolute path to a stored image to match against"},
                "sessionId": {"type": "string", "description": "Filter to a single session"},
                "topK": {"type": "integer", "description": "Max results (default: 10, max 50)"},
            },
        },
    },
    {
        "name": "memory_timeline",
        "description": "Chronological observations around an anchor point.",
        "parameters": {
            "type": "object",
            "properties": {
                "anchor": {"type": "string", "description": "Anchor point: ISO date or keyword"},
                "before": {"type": "integer", "description": "Observations before anchor (default: 5)"},
                "after": {"type": "integer", "description": "Observations after anchor (default: 5)"},
                "project": {"type": "string", "description": "Filter by project path"},
            },
            "required": ["anchor"],
        },
    },
    {
        "name": "memory_profile",
        "description": "User/project profile with top concepts and file patterns.",
        "parameters": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Project path"},
                "refresh": {"type": "string", "description": "Set to 'true' to force rebuild"},
            },
            "required": ["project"],
        },
    },
    {
        "name": "memory_export",
        "description": "Export all memory data as JSON.",
        "parameters": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "memory_relations",
        "description": "Query the memory relationship graph.",
        "parameters": {
            "type": "object",
            "properties": {
                "memoryId": {"type": "string", "description": "Memory ID to find relations for"},
                "maxHops": {"type": "integer", "description": "Max traversal depth (default: 2)"},
                "minConfidence": {"type": "number", "description": "Min confidence (0-1, default: 0)"},
            },
            "required": ["memoryId"],
        },
    },
    {
        "name": "memory_commit_lookup",
        "description": "Look up the agent session(s) that produced a specific git commit, given its SHA. Returns the commit metadata and linked observations.",
        "parameters": {
            "type": "object",
            "properties": {
                "sha": {"type": "string", "description": "Full git commit SHA"},
            },
            "required": ["sha"],
        },
    },
    {
        "name": "memory_commits",
        "description": "List recent commits linked to agent sessions, optionally filtered by branch or repo.",
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {"type": "string", "description": "Filter by branch name"},
                "limit": {"type": "integer", "description": "Max results (default: 100, max 500)"},
                "repo": {"type": "string", "description": "Filter by remote URL"},
            },
        },
    },
    {
        "name": "memory_file_history",
        "description": "Get past observations about specific files.",
        "parameters": {
            "type": "object",
            "properties": {
                "files": {"type": "string", "description": "Comma-separated file paths"},
                "sessionId": {"type": "string", "description": "Current session ID to exclude"},
            },
            "required": ["files"],
        },
    },
    {
        "name": "memory_patterns",
        "description": "Detect recurring patterns across sessions.",
        "parameters": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Project path to analyze"},
            },
        },
    },
    {
        "name": "memory_sessions",
        "description": "List recent sessions with their status and observation counts.",
        "parameters": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "memory_compress_file",
        "description": "Compress a markdown file to reduce token usage while preserving headings, URLs, and code blocks. Creates a .original.md backup.",
        "parameters": {
            "type": "object",
            "properties": {
                "filePath": {"type": "string", "description": "Path to the markdown file to compress"},
            },
            "required": ["filePath"],
        },
    },
    # === v0.40: Claude Code integration ===
    {
        "name": "memory_claude_bridge_sync",
        "description": "Sync memory state to/from Claude Code's native MEMORY.md file.",
        "parameters": {
            "type": "object",
            "properties": {
                "direction": {"type": "string", "enum": ["read", "write"], "description": "'read' to import from MEMORY.md, 'write' to export to MEMORY.md"},
            },
            "required": ["direction"],
        },
    },
    {
        "name": "memory_graph_query",
        "description": "Query the knowledge graph for entities and relationships.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search nodes by name"},
                "maxDepth": {"type": "integer", "description": "Max BFS depth (default: 3, max 5)"},
                "nodeType": {"type": "string", "description": "Filter by node type"},
                "startNodeId": {"type": "string", "description": "Starting node ID for traversal"},
            },
        },
    },
    {
        "name": "memory_consolidate",
        "description": "Run the 4-tier memory consolidation pipeline (working -> episodic -> semantic -> procedural).",
        "parameters": {
            "type": "object",
            "properties": {
                "tier": {"type": "string", "enum": ["episodic", "semantic", "procedural"], "description": "Target tier"},
            },
        },
    },
    {
        "name": "memory_team_share",
        "description": "Share a memory or observation with team members.",
        "parameters": {
            "type": "object",
            "properties": {
                "itemId": {"type": "string", "description": "ID of memory or observation to share"},
                "itemType": {"type": "string", "enum": ["observation", "memory", "pattern"], "description": "Type: observation, memory, or pattern"},
            },
            "required": ["itemId", "itemType"],
        },
    },
    {
        "name": "memory_team_feed",
        "description": "Get recent shared items from all team members.",
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max items (default: 20)"},
            },
        },
    },
    {
        "name": "memory_audit",
        "description": "View the audit trail of memory operations.",
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max entries (default: 50)"},
                "operation": {"type": "string", "description": "Filter by operation type"},
            },
        },
    },
    {
        "name": "memory_governance_delete",
        "description": "Delete specific memories with audit trail.",
        "parameters": {
            "type": "object",
            "properties": {
                "memoryIds": {"type": "string", "description": "Comma-separated memory IDs to delete"},
                "reason": {"type": "string", "description": "Reason for deletion"},
            },
            "required": ["memoryIds"],
        },
    },
    {
        "name": "memory_snapshot_create",
        "description": "Create a git-versioned snapshot of current memory state.",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "Snapshot description"},
            },
        },
    },
    # === v0.50: Actions and workflow ===
    {
        "name": "memory_action_create",
        "description": "Create an actionable work item with typed dependencies. Actions track what agents need to do and how work items relate to each other.",
        "parameters": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Action title"},
                "description": {"type": "string", "description": "Detailed description of the work"},
                "priority": {"type": "number", "description": "Priority 1-10 (10 highest)"},
                "project": {"type": "string", "description": "Project path"},
                "parentId": {"type": "string", "description": "Parent action ID for hierarchical actions"},
                "requires": {"type": "string", "description": "Comma-separated action IDs that must complete before this"},
                "tags": {"type": "string", "description": "Comma-separated tags"},
            },
            "required": ["title"],
        },
    },
    {
        "name": "memory_action_update",
        "description": "Update an action's status, priority, or details. Set status to 'done' to complete it and unblock dependent actions.",
        "parameters": {
            "type": "object",
            "properties": {
                "actionId": {"type": "string", "description": "Action ID to update"},
                "status": {"type": "string", "enum": ["pending", "active", "done", "blocked", "cancelled"], "description": "New status"},
                "priority": {"type": "number", "description": "New priority 1-10"},
                "result": {"type": "string", "description": "Outcome description (when completing)"},
            },
            "required": ["actionId", "status"],
        },
    },
    {
        "name": "memory_frontier",
        "description": "Get all unblocked actions ranked by priority and urgency. Returns the frontier of actionable work with no unsatisfied dependencies.",
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max results (default: 20)"},
                "project": {"type": "string", "description": "Filter by project"},
                "agentId": {"type": "string", "description": "Agent ID to check lease conflicts"},
            },
        },
    },
    {
        "name": "memory_next",
        "description": "Get the single most important next action to work on. Combines dependency resolution, priority, and recency into a score.",
        "parameters": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Filter by project"},
                "agentId": {"type": "string", "description": "Current agent ID"},
            },
        },
    },
    {
        "name": "memory_lease",
        "description": "Acquire, release, or renew an exclusive lease on an action. Prevents multiple agents from working on the same thing.",
        "parameters": {
            "type": "object",
            "properties": {
                "actionId": {"type": "string", "description": "Action ID"},
                "agentId": {"type": "string", "description": "Agent claiming the action"},
                "operation": {"type": "string", "enum": ["acquire", "release", "renew"], "description": "acquire, release, or renew"},
                "ttlMs": {"type": "integer", "description": "Lease duration in ms (default 10min, max 1hr)"},
                "result": {"type": "string", "description": "Result when releasing (marks action done)"},
            },
            "required": ["actionId", "agentId", "operation"],
        },
    },
    {
        "name": "memory_routine_run",
        "description": "Instantiate a frozen workflow routine, creating actions for each step with proper dependencies.",
        "parameters": {
            "type": "object",
            "properties": {
                "routineId": {"type": "string", "description": "Routine template ID"},
                "project": {"type": "string", "description": "Project context"},
                "initiatedBy": {"type": "string", "description": "Agent starting the run"},
            },
            "required": ["routineId"],
        },
    },
    {
        "name": "memory_signal_send",
        "description": "Send a message to another agent or broadcast. Supports threading, typed messages, and TTL expiration.",
        "parameters": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Message content"},
                "from": {"type": "string", "description": "Sender agent ID"},
                "to": {"type": "string", "description": "Recipient agent ID (omit for broadcast)"},
                "type": {"type": "string", "enum": ["info", "request", "response", "alert", "handoff"], "description": "Message type"},
                "replyTo": {"type": "string", "description": "Signal ID to reply to (auto-threads)"},
            },
            "required": ["content", "from"],
        },
    },
    {
        "name": "memory_signal_read",
        "description": "Read messages for an agent. Marks delivered messages as read.",
        "parameters": {
            "type": "object",
            "properties": {
                "agentId": {"type": "string", "description": "Agent to read messages for"},
                "limit": {"type": "integer", "description": "Max messages (default: 50)"},
                "threadId": {"type": "string", "description": "Filter by conversation thread"},
                "unreadOnly": {"type": "string", "description": "Set to 'true' for unread only"},
            },
            "required": ["agentId"],
        },
    },
    {
        "name": "memory_checkpoint",
        "description": "Create or resolve an external checkpoint (CI result, approval, deploy status) that gates action progress.",
        "parameters": {
            "type": "object",
            "properties": {
                "operation": {"type": "string", "enum": ["create", "resolve", "list"], "description": "create, resolve, or list"},
                "checkpointId": {"type": "string", "description": "Checkpoint ID (for resolve)"},
                "name": {"type": "string", "description": "Checkpoint name (for create)"},
                "type": {"type": "string", "enum": ["ci", "approval", "deploy", "external", "timer"], "description": "Checkpoint type (for create)"},
                "linkedActionIds": {"type": "string", "description": "Comma-separated action IDs this checkpoint gates (for create)"},
                "status": {"type": "string", "enum": ["passed", "failed"], "description": "passed or failed (for resolve)"},
            },
            "required": ["operation"],
        },
    },
    {
        "name": "memory_mesh_sync",
        "description": "Sync memories and actions with peer agentmemory instances for multi-agent collaboration.",
        "parameters": {
            "type": "object",
            "properties": {
                "direction": {"type": "string", "enum": ["push", "pull", "both"], "description": "push, pull, or both (default both)"},
                "peerId": {"type": "string", "description": "Specific peer ID (omit for all)"},
            },
        },
    },
    # === v0.51: Sentinels ===
    {
        "name": "memory_sentinel_create",
        "description": "Create an event-driven sentinel that watches for conditions (webhook, timer, threshold, pattern, approval) and auto-unblocks gated actions.",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Sentinel name"},
                "type": {"type": "string", "enum": ["webhook", "timer", "threshold", "pattern", "approval", "custom"], "description": "Type: webhook, timer, threshold, pattern, approval, custom"},
                "config": {"type": "string", "description": "JSON config (timer: {durationMs}, threshold: {metric,operator,value}, pattern: {regex}, approval: {approvers}, custom: {handler})"},
                "linkedActionIds": {"type": "string", "description": "Comma-separated action IDs to gate"},
                "expiresInMs": {"type": "integer", "description": "Auto-expire after ms"},
            },
            "required": ["name", "type", "config"],
        },
    },
    {
        "name": "memory_sentinel_trigger",
        "description": "Externally fire a sentinel, providing an optional result payload. Unblocks any gated actions.",
        "parameters": {
            "type": "object",
            "properties": {
                "sentinelId": {"type": "string", "description": "Sentinel ID to trigger"},
                "result": {"type": "string", "description": "JSON result payload"},
            },
            "required": ["sentinelId"],
        },
    },
    # === Sketches ===
    {
        "name": "memory_sketch_create",
        "description": "Create an ephemeral action graph for exploratory work. Auto-expires after TTL. Can be promoted to permanent actions or discarded.",
        "parameters": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Sketch title"},
                "description": {"type": "string", "description": "What this sketch explores"},
                "project": {"type": "string", "description": "Project context"},
                "expiresInMs": {"type": "integer", "description": "TTL in ms (default 1 hour)"},
            },
            "required": ["title"],
        },
    },
    {
        "name": "memory_sketch_promote",
        "description": "Promote a sketch's ephemeral actions to permanent actions. Makes the exploratory work official.",
        "parameters": {
            "type": "object",
            "properties": {
                "sketchId": {"type": "string", "description": "Sketch ID to promote"},
                "project": {"type": "string", "description": "Override project for promoted actions"},
            },
            "required": ["sketchId"],
        },
    },
    {
        "name": "memory_crystallize",
        "description": "Compress completed action chains into compact crystal digests using LLM summarization. Extracts narrative, key outcomes, and reusable patterns.",
        "parameters": {
            "type": "object",
            "properties": {
                "actionIds": {"type": "string", "description": "Comma-separated completed action IDs to crystallize"},
                "project": {"type": "string", "description": "Project context"},
                "sessionId": {"type": "string", "description": "Session context"},
            },
            "required": ["actionIds"],
        },
    },
    # === Diagnostics ===
    {
        "name": "memory_diagnose",
        "description": "Run health checks across all subsystems (actions, leases, sentinels, sketches, signals, sessions, memories, mesh). Identifies stuck actions, stale leases, and orphaned data.",
        "parameters": {
            "type": "object",
            "properties": {
                "categories": {"type": "string", "description": "Comma-separated categories to check (default all)"},
            },
        },
    },
    {
        "name": "memory_heal",
        "description": "Auto-fix all fixable issues found by diagnostics. Unblocks stuck actions, expires stale leases, cleans up orphaned data.",
        "parameters": {
            "type": "object",
            "properties": {
                "categories": {"type": "string", "description": "Comma-separated categories to heal (default all)"},
                "dryRun": {"type": "string", "description": "Set to 'true' for dry run (report but don't fix)"},
            },
        },
    },
    # === Facets ===
    {
        "name": "memory_facet_tag",
        "description": "Attach a structured tag (dimension:value) to an action, memory, or observation for multi-dimensional categorization.",
        "parameters": {
            "type": "object",
            "properties": {
                "targetId": {"type": "string", "description": "ID of the target to tag"},
                "targetType": {"type": "string", "enum": ["action", "memory", "observation"], "description": "Type: action, memory, or observation"},
                "dimension": {"type": "string", "description": "Tag dimension (e.g., priority, team, status)"},
                "value": {"type": "string", "description": "Tag value (e.g., urgent, backend, reviewed)"},
            },
            "required": ["targetId", "targetType", "dimension", "value"],
        },
    },
    {
        "name": "memory_facet_query",
        "description": "Query targets by facet tags with AND/OR logic. Find all actions tagged priority:urgent AND team:backend.",
        "parameters": {
            "type": "object",
            "properties": {
                "matchAll": {"type": "string", "description": "Comma-separated dimension:value pairs (AND logic)"},
                "matchAny": {"type": "string", "description": "Comma-separated dimension:value pairs (OR logic)"},
                "targetType": {"type": "string", "enum": ["action", "memory", "observation"], "description": "Filter by type: action, memory, or observation"},
            },
        },
    },
    # === Verify ===
    {
        "name": "memory_verify",
        "description": "Verify a memory or observation by tracing its citation chain back to source observations and session context. Returns provenance trail.",
        "parameters": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "Memory ID or observation ID to verify"},
            },
            "required": ["id"],
        },
    },
    # === v0.70: Lessons ===
    {
        "name": "memory_lesson_save",
        "description": "Save a lesson learned from this session. Lessons have confidence scores that strengthen when reinforced and decay when not used. Distinct from memory_save: lessons are actionable 'how-to' knowledge.",
        "parameters": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The lesson learned (what worked, what to avoid, when to use X approach)"},
                "confidence": {"type": "number", "description": "Initial confidence 0.0-1.0 (default 0.5)"},
                "context": {"type": "string", "description": "When/where this lesson applies"},
                "project": {"type": "string", "description": "Project this lesson is about"},
                "tags": {"type": "string", "description": "Comma-separated tags"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "memory_lesson_recall",
        "description": "Search lessons by query. Returns lessons sorted by confidence and recency. Use to check what the agent has learned before making a decision.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "limit": {"type": "integer", "description": "Max results (default: 10)"},
                "minConfidence": {"type": "number", "description": "Minimum confidence threshold (default 0.1)"},
                "project": {"type": "string", "description": "Filter by project"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_obsidian_export",
        "description": "Export memories, lessons, and crystals as Obsidian-compatible Markdown files with YAML frontmatter and wikilinks for graph navigation.",
        "parameters": {
            "type": "object",
            "properties": {
                "vaultDir": {"type": "string", "description": "Output directory (default ~/.agentmemory/vault/)"},
                "types": {"type": "string", "description": "Comma-separated types to export: memories,lessons,crystals,sessions (default all)"},
            },
        },
    },
    # === v0.73: Insights ===
    {
        "name": "memory_reflect",
        "description": "Traverse the knowledge graph, group related memories by concept clusters, and synthesize higher-order insights via LLM. Returns new and reinforced insights.",
        "parameters": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Filter by project"},
                "maxClusters": {"type": "integer", "description": "Max concept clusters to process (default 10, max 20)"},
            },
        },
    },
    {
        "name": "memory_insight_list",
        "description": "List synthesized insights — higher-order observations derived from patterns across memories, lessons, and crystals.",
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max results (default: 50)"},
                "minConfidence": {"type": "number", "description": "Minimum confidence threshold (default 0)"},
                "project": {"type": "string", "description": "Filter by project"},
            },
        },
    },
    # === v0.10: Memory Slots ===
    {
        "name": "memory_slot_list",
        "description": "List all memory slots (pinned + project + global). Slots are editable, size-limited memory units the agent can read and modify directly.",
        "parameters": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "memory_slot_get",
        "description": "Read a single slot by label.",
        "parameters": {
            "type": "object",
            "properties": {
                "label": {"type": "string", "description": "Slot label (e.g. 'persona', 'pending_items')"},
            },
            "required": ["label"],
        },
    },
    {
        "name": "memory_slot_create",
        "description": "Create a new slot. Reject if a slot with the same label already exists.",
        "parameters": {
            "type": "object",
            "properties": {
                "label": {"type": "string", "description": "Slot label — lowercase, starts with letter, [a-z0-9_]"},
                "content": {"type": "string", "description": "Initial content (default empty)"},
                "description": {"type": "string", "description": "What this slot is for"},
                "scope": {"type": "string", "enum": ["project", "global"], "description": "'project' (default) or 'global' (shared across projects)"},
                "pinned": {"type": "string", "description": "'false' to exclude from context injection; default true"},
                "sizeLimit": {"type": "integer", "description": "Max chars (default 2000, hard cap 20000)"},
            },
            "required": ["label"],
        },
    },
    {
        "name": "memory_slot_append",
        "description": "Append text to an existing slot. Fails with 413 if the append would exceed the slot's sizeLimit — agent must compact via memory_slot_replace.",
        "parameters": {
            "type": "object",
            "properties": {
                "label": {"type": "string", "description": "Slot label"},
                "text": {"type": "string", "description": "Text to append"},
            },
            "required": ["label", "text"],
        },
    },
    {
        "name": "memory_slot_replace",
        "description": "Replace slot content in place. Fails if content exceeds sizeLimit.",
        "parameters": {
            "type": "object",
            "properties": {
                "label": {"type": "string", "description": "Slot label"},
                "content": {"type": "string", "description": "New full content"},
            },
            "required": ["label", "content"],
        },
    },
    {
        "name": "memory_slot_delete",
        "description": "Delete a slot. Seeded default slots can be deleted unless marked readOnly.",
        "parameters": {
            "type": "object",
            "properties": {
                "label": {"type": "string", "description": "Slot label"},
            },
            "required": ["label"],
        },
    },
]


# ============================================
# Memory Provider — делегирует ВСЁ в MCP
# ============================================

class AgentMemoryMCPProvider:
    """
    MemoryProvider для AgentMemory.
    
    ВСЕ операции делегируются в MCP-сервер agentmemory.
    MCP-сервер подключён в config.yaml как mcp_servers.agentmemory.
    
    Этот плагин:
    1. Регистрирует 53 tool schemas в Hermes tool registry
    2. Prefetch: вызывает memory_recall через MCP перед каждым обращением к LLM
    3. Sync: вызывает memory_save через MCP после каждого хода
    4. Session end: вызывает memory_consolidate при завершении сессии
    """

    def __init__(self):
        self._session_id: str = ""
        self._user_id: str = ""
        self._agent_id: str = ""
        self._prefetch_enabled: bool = True
        self._sync_enabled: bool = True
        self._prefetch_k: int = 5
        self._turn_count: int = 0
        self._last_prefetch_time: float = 0
        self._prefetch_cache: str = ""

    @property
    def name(self) -> str:
        return "agentmemory_mcp"

    def is_available(self) -> bool:
        """AgentMemory доступен если есть MCP-сервер в конфиге."""
        return True  # MCP сервер уже подключён через mcp_servers

    def initialize(self, session_id: str, **kwargs: Any) -> None:
        self._session_id = session_id
        self._user_id = str(kwargs.get("user_id") or "").strip()
        self._agent_id = os.environ.get("AGENTMEMORY_AGENT_ID", "hermes")
        self._prefetch_enabled = os.environ.get("AGENTMEMORY_PREFETCH_ENABLED", "true").lower() == "true"
        self._sync_enabled = os.environ.get("AGENTMEMORY_SYNC_ENABLED", "true").lower() == "true"
        self._prefetch_k = int(os.environ.get("AGENTMEMORY_PREFETCH_K", "5"))

        logger.info(
            "AgentMemoryMCPProvider initialized (agent=%s, prefetch=%s, sync=%s, tools=%d)",
            self._agent_id, self._prefetch_enabled, self._sync_enabled, len(ALL_SCHEMAS),
        )

    def shutdown(self) -> None:
        pass

    def system_prompt_block(self) -> str:
        return (
            "[AgentMemory: долгосрочная память активна. "
            "53 инструмента: memory_recall, memory_save, memory_smart_search, "
            "memory_vision_search, memory_graph_query, memory_patterns, memory_timeline, "
            "memory_consolidate, memory_sessions, memory_profile, memory_relations, "
            "memory_export, memory_audit, memory_file_history, memory_compress_file, "
            "memory_commit_lookup, memory_commits, "
            "memory_team_share, memory_team_feed, memory_claude_bridge_sync, "
            "memory_snapshot_create, memory_action_create, memory_action_update, "
            "memory_frontier, memory_next, memory_lease, memory_routine_run, "
            "memory_signal_send, memory_signal_read, memory_checkpoint, memory_mesh_sync, "
            "memory_sentinel_create, memory_sentinel_trigger, memory_sketch_create, "
            "memory_sketch_promote, memory_crystallize, memory_diagnose, memory_heal, "
            "memory_facet_tag, memory_facet_query, memory_verify, memory_governance_delete, "
            "memory_lesson_save, memory_lesson_recall, memory_obsidian_export, "
            "memory_reflect, memory_insight_list, "
            "memory_slot_list, memory_slot_get, memory_slot_create, "
            "memory_slot_append, memory_slot_replace, memory_slot_delete]"
        )

    def prefetch(self, query: str, *, session_id: str = "") -> str:
        """
        Prefetch через MCP memory_recall.
        Вызывается перед каждым обращением к LLM.
        """
        if not self._prefetch_enabled or not query or not query.strip():
            return ""

        now = time.time()
        if now - self._last_prefetch_time < 2.0 and self._prefetch_cache:
            return self._prefetch_cache

        # Prefetch делается через MCP tool call — но тут мы не можем
        # напрямую вызвать MCP, потому что это делает Hermes.
        # Вместо этого возвращаем подсказку для агента.
        self._last_prefetch_time = now
        self._prefetch_cache = ""
        return ""

    def queue_prefetch(self, query: str, *, session_id: str = "") -> None:
        pass

    def sync_turn(self, user_content: str, assistant_content: str, *, session_id: str = "") -> None:
        """
        Sync через MCP memory_save.
        Вызывается после каждого хода.
        """
        if not self._sync_enabled:
            return
        self._turn_count += 1
        if self._turn_count % 3 != 0:
            return
        # Sync делается через MCP tool call — но тут мы не можем
        # напрямую вызвать MCP, потому что это делает Hermes.
        pass

    def get_tool_schemas(self) -> List[Dict[str, Any]]:
        """Все 53 инструмента AgentMemory v0.9.21."""
        return ALL_SCHEMAS

    def handle_tool_call(self, tool_name: str, args: Dict[str, Any], **kwargs) -> str:
        """
        Обработка вызова инструмента.
        ВСЕ инструменты делегируются в MCP-сервер agentmemory.
        Hermes сам вызовет MCP tool через mcp_servers.agentmemory.
        """
        return json.dumps({
            "ok": True,
            "message": f"Tool {tool_name} delegated to AgentMemory MCP server",
            "args": args,
        }, ensure_ascii=False)

    def on_session_end(self, messages: List[Dict[str, Any]]) -> None:
        """При завершении сессии — consolidation через MCP."""
        pass


# ============================================
# Plugin entry point
# ============================================
_provider: Optional[AgentMemoryMCPProvider] = None


def register(ctx=None):
    global _provider
    _provider = AgentMemoryMCPProvider()
    if ctx and hasattr(ctx, "register_memory_provider"):
        ctx.register_memory_provider(_provider)


def initialize(session_id: str, **kwargs: Any) -> None:
    global _provider
    if _provider is None:
        _provider = AgentMemoryMCPProvider()
    _provider.initialize(session_id, **kwargs)


def shutdown() -> None:
    global _provider
    if _provider:
        _provider.shutdown()
        _provider = None


def get_tool_schemas() -> List[Dict[str, Any]]:
    return ALL_SCHEMAS


def handle_tool_call(tool_name: str, args: Dict[str, Any], **kwargs: Any) -> str:
    if _provider is None:
        return json.dumps({"error": "AgentMemory provider not initialized"})
    return _provider.handle_tool_call(tool_name, args, **kwargs)
